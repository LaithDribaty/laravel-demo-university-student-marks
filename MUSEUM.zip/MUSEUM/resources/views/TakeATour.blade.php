@extends('layouts.app')

@section('head')

	<script type="text/javascript">
		
		function show(strId) {
			document.getElementById(strId).style.opacity = "0.3";
		}

		function hide(strId) {
			document.getElementById(strId).style.opacity = "0.00";
		}

	</script>

	<style type="text/css">
		body {
			height: 1050px;
		}

		.img-overlay-wrap {
			position: relative;
			display: inline-block; /* <= shrinks container to image size */
			transition: transform 150ms ease-in-out;
			width:100%;
			height:100%;
		}

		.img-overlay-wrap img { /* <= optional, for responsiveness */
			display: block;
			width:100%;
			height:auto;
			position:relative;
		}

		.img-overlay-wrap svg {
			position: absolute;
			top: 0;
			left: 0;
			width: 100%;
		    height: auto;
		}

	</style>

	<link rel="stylesheet" href="/MUSEUM/public/css/slider.css" />

	
@endsection

@section('bodyFinish')
	<!-- ======= Top Bar ======= -->
	<div id="topbar" class="d-flex align-items-center fixed-top">
    <div class="container d-flex">
      <div class="contact-info mr-auto">
        <i class="icofont-phone"></i> +963-937-341-249
        <span class="d-none d-lg-inline-block"><i class="icofont-clock-time icofont-rotate-180"></i> On demand </span>
      </div>
    </div>
  </div>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top">
    <div class="container d-flex align-items-center">

      <h1 class="logo mr-auto"><a href="/MUSEUM/public">{{trans('text.museum')}}</a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="./" class="logo mr-auto"><img src="img/logo.png" alt="" class="img-fluid"></a>-->

      <nav class="nav-menu d-none d-lg-block">
        <ul>
          <li><a href="/MUSEUM/public">{{ trans('text.home') }}</a></li>
          <li><a href="/MUSEUM/public/#about">{{ trans('text.about') }}</a></li>
          <!--<li><a href="/MUSEUM/public/#menu">Menu</a></li>-->
          <!--<li><a href="./#specials">Specials</a></li>-->
          <li><a href="/MUSEUM/public/#events">{{ trans('text.events')}}</a></li>
          <li><a href="/MUSEUM/public/#gallery">{{ trans('text.gallery')}}</a></li>
          <li><a href="/MUSEUM/public/#chefs">{{ trans('text.team')}}</a></li>
          <li><a href="/MUSEUM/public/#contact">{{ trans('text.contact')}}</a></li>
          <li class="book-a-table text-center"><a href="/MUSEUM/public/#book-a-table">{{ trans('text.demand_a_visit')}}</a></li>
        </ul>
      </nav><!-- .nav-menu -->

    </div>
  	</header><!-- End Header -->

	<br><br>
	<section>
		<div class="img-overlay-wrap">
			<img src="/MUSEUM/public/img/{{$section[0]->pictures}}" style="opacity: 0.8;">
			<svg viewBox="0 0 1280 720">
				@foreach($data as $nxx)
					@if($nxx->moveable)
						<a href="/MUSEUM/public/TakeATour/{{ $nxx->moveable }}">
							<path d="{{ $nxx->Position }}" style="stroke: black; opacity: 0.0;" onmouseover="show({{$nxx->ID}});" onmouseleave="hide('{{$nxx->ID}}');" id="{{$nxx->ID}}" />
						</a>
					@else
						<path d="{{ $nxx->Position }}" style="stroke: black; opacity: 0.0;" onmouseover="show({{$nxx->ID}});" onmouseleave="hide('{{$nxx->ID}}');" id="{{$nxx->ID}}"/>
					@endif
				@endforeach
			</svg>
		</div>
	</section>

	<center>
		<a href="../TakeATour/map" class="btn btn-primary"> 
			go back to map
		</a>
		
		<a href="../TakeATour/intro" class="btn btn-success"> 
			go back to intro
		</a>
	</center>

	<div id="dialog2" title="abreek">
 		<p>This is an abreek for matte poor in glass.</p>
	</div>

	<script src="/MUSEUM/resources/assets/vendor/jquery/jquery.min.js"></script>
	<script src="/MUSEUM/resources/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
	<script src="/MUSEUM/resources/assets/vendor/jquery.easing/jquery.easing.min.js"></script>
	<script src="/MUSEUM/resources/assets/vendor/php-email-form/validate.js"></script>
	<script src="/MUSEUM/resources/assets/vendor/owl.carousel/owl.carousel.min.js"></script>
	<script src="/MUSEUM/resources/assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
	<script src="/MUSEUM/resources/assets/vendor/venobox/venobox.min.js"></script>
	<script src="/MUSEUM/resources/assets/vendor/aos/aos.js"></script>
	<script src="/MUSEUM/resources/assets/js/main.js"></script>
	<script src="/MUSEUM/public/js/jquery-1.11.0.min.js"></script>
    <script src="/MUSEUM/public/js/slider.js"></script>
	<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
	<link rel="stylesheet" href="https://jqueryui.com/resources/demos/style.css">
	<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
	<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

	<script>
	@foreach($data as $nxx)
		@if(!$nxx->moveable)
			$( function() {
					$( "#dialog{{ $nxx->ID }}" ).dialog({
						autoOpen: false,
						show: {
							effect: "blind",
							duration: 500
						},
						hide: {
							effect: "explode",
							duration: 500
						}
					});

					$( "#{{$nxx->ID}}" ).on( "click", function() {
						$( "#dialog{{ $nxx->ID }}" ).dialog( "open" );
					});
			} );
		@endif
	@endforeach
	</script>

@endsection
