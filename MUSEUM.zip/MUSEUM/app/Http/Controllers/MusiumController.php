<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Models\Stuff;
use App\Models\Section;
use Session;
use URL;

class MusiumController extends Controller
{
    public function locatePlace($place) {
        // here to bring the correct $place MAP AND PHOTOS URL
        $data = Stuff::where('Section', "$place")->get();
        $section = Section::where('section', "$place")->get();
        if( count($section) == 0 ) 
            return redirect('/TakeATour/test');

        return view('TakeATour')->with('data' , $data)->with('section' , $section);
    }
}

